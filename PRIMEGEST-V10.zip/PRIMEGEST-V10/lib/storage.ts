import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';

export interface Company {
  name: string;
  cnpj: string;
  address: string;
  phone: string;
}

export interface AdminUser {
  username: string;
  passwordHash: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  stock: number;
  category: string;
  active: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Sale {
  id: string;
  items: CartItem[];
  total: number;
  paymentMethod: string;
  date: string;
  status: 'completed' | 'cancelled' | 'refunded';
  cancelledAt?: string;
  refundedAt?: string;
}

export interface CashRegister {
  id: string;
  openedAt: string;
  closedAt?: string;
  openingAmount: number;
  closingAmount?: number;
  movements: CashMovement[];
  status: 'open' | 'closed';
}

export interface CashMovement {
  id: string;
  type: 'supply' | 'withdrawal' | 'sale' | 'refund';
  amount: number;
  description: string;
  date: string;
}

const KEYS = {
  COMPANY: '@pdv_company',
  ADMIN: '@pdv_admin',
  PRODUCTS: '@pdv_products',
  SALES: '@pdv_sales',
  CASH_REGISTERS: '@pdv_cash_registers',
  SETUP_DONE: '@pdv_setup_done',
};

async function hashPassword(password: string): Promise<string> {
  const digest = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    password
  );
  return digest;
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const inputHash = await hashPassword(password);
  return inputHash === hash;
}

export async function isSetupDone(): Promise<boolean> {
  const val = await AsyncStorage.getItem(KEYS.SETUP_DONE);
  return val === 'true';
}

export async function saveSetup(company: Company, username: string, password: string): Promise<void> {
  const passwordHash = await hashPassword(password);
  const admin: AdminUser = { username, passwordHash };
  await AsyncStorage.multiSet([
    [KEYS.COMPANY, JSON.stringify(company)],
    [KEYS.ADMIN, JSON.stringify(admin)],
    [KEYS.SETUP_DONE, 'true'],
  ]);
}

export async function getCompany(): Promise<Company | null> {
  const val = await AsyncStorage.getItem(KEYS.COMPANY);
  return val ? JSON.parse(val) : null;
}

export async function getAdmin(): Promise<AdminUser | null> {
  const val = await AsyncStorage.getItem(KEYS.ADMIN);
  return val ? JSON.parse(val) : null;
}

export async function getProducts(): Promise<Product[]> {
  const val = await AsyncStorage.getItem(KEYS.PRODUCTS);
  return val ? JSON.parse(val) : [];
}

export async function saveProduct(product: Omit<Product, 'id' | 'active'>): Promise<Product> {
  const products = await getProducts();
  const newProduct: Product = {
    ...product,
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    active: true,
  };
  products.push(newProduct);
  await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  return newProduct;
}

export async function updateProduct(product: Product): Promise<void> {
  const products = await getProducts();
  const idx = products.findIndex(p => p.id === product.id);
  if (idx !== -1) {
    products[idx] = product;
    await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  }
}

export async function deleteProduct(id: string): Promise<void> {
  const products = await getProducts();
  const filtered = products.filter(p => p.id !== id);
  await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(filtered));
}

export async function updateStock(productId: string, quantityChange: number): Promise<void> {
  const products = await getProducts();
  const idx = products.findIndex(p => p.id === productId);
  if (idx !== -1) {
    products[idx].stock += quantityChange;
    await AsyncStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
  }
}

export async function getSales(): Promise<Sale[]> {
  const val = await AsyncStorage.getItem(KEYS.SALES);
  return val ? JSON.parse(val) : [];
}

export async function saveSale(sale: Omit<Sale, 'id'>): Promise<Sale> {
  const sales = await getSales();
  const newSale: Sale = {
    ...sale,
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
  };
  sales.push(newSale);
  await AsyncStorage.setItem(KEYS.SALES, JSON.stringify(sales));

  for (const item of sale.items) {
    await updateStock(item.product.id, -item.quantity);
  }

  const register = await getOpenCashRegister();
  if (register) {
    register.movements.push({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      type: 'sale',
      amount: sale.total,
      description: `Venda #${newSale.id.slice(-6)}`,
      date: new Date().toISOString(),
    });
    await updateCashRegister(register);
  }

  return newSale;
}

export async function cancelSale(saleId: string): Promise<void> {
  const sales = await getSales();
  const idx = sales.findIndex(s => s.id === saleId);
  if (idx !== -1) {
    sales[idx].status = 'cancelled';
    sales[idx].cancelledAt = new Date().toISOString();
    await AsyncStorage.setItem(KEYS.SALES, JSON.stringify(sales));

    for (const item of sales[idx].items) {
      await updateStock(item.product.id, item.quantity);
    }
  }
}

export async function refundSale(saleId: string): Promise<void> {
  const sales = await getSales();
  const idx = sales.findIndex(s => s.id === saleId);
  if (idx !== -1) {
    sales[idx].status = 'refunded';
    sales[idx].refundedAt = new Date().toISOString();
    await AsyncStorage.setItem(KEYS.SALES, JSON.stringify(sales));

    for (const item of sales[idx].items) {
      await updateStock(item.product.id, item.quantity);
    }

    const register = await getOpenCashRegister();
    if (register) {
      register.movements.push({
        id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
        type: 'refund',
        amount: -sales[idx].total,
        description: `Estorno #${saleId.slice(-6)}`,
        date: new Date().toISOString(),
      });
      await updateCashRegister(register);
    }
  }
}

export async function getCashRegisters(): Promise<CashRegister[]> {
  const val = await AsyncStorage.getItem(KEYS.CASH_REGISTERS);
  return val ? JSON.parse(val) : [];
}

export async function getOpenCashRegister(): Promise<CashRegister | null> {
  const registers = await getCashRegisters();
  return registers.find(r => r.status === 'open') || null;
}

export async function openCashRegister(openingAmount: number): Promise<CashRegister> {
  const registers = await getCashRegisters();
  const newRegister: CashRegister = {
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    openedAt: new Date().toISOString(),
    openingAmount,
    movements: [],
    status: 'open',
  };
  registers.push(newRegister);
  await AsyncStorage.setItem(KEYS.CASH_REGISTERS, JSON.stringify(registers));
  return newRegister;
}

export async function closeCashRegister(closingAmount: number): Promise<void> {
  const registers = await getCashRegisters();
  const idx = registers.findIndex(r => r.status === 'open');
  if (idx !== -1) {
    registers[idx].status = 'closed';
    registers[idx].closedAt = new Date().toISOString();
    registers[idx].closingAmount = closingAmount;
    await AsyncStorage.setItem(KEYS.CASH_REGISTERS, JSON.stringify(registers));
  }
}

export async function addCashMovement(type: 'supply' | 'withdrawal', amount: number, description: string): Promise<void> {
  const registers = await getCashRegisters();
  const idx = registers.findIndex(r => r.status === 'open');
  if (idx !== -1) {
    registers[idx].movements.push({
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      type,
      amount: type === 'withdrawal' ? -amount : amount,
      description,
      date: new Date().toISOString(),
    });
    await AsyncStorage.setItem(KEYS.CASH_REGISTERS, JSON.stringify(registers));
  }
}

export async function updateCashRegister(register: CashRegister): Promise<void> {
  const registers = await getCashRegisters();
  const idx = registers.findIndex(r => r.id === register.id);
  if (idx !== -1) {
    registers[idx] = register;
    await AsyncStorage.setItem(KEYS.CASH_REGISTERS, JSON.stringify(registers));
  }
}

export function formatCurrency(value: number): string {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export function generateReceipt(sale: Sale, company: Company | null): string {
  const width = 32;
  const line = '-'.repeat(width);
  const doubleLine = '='.repeat(width);
  const center = (text: string) => {
    const pad = Math.max(0, Math.floor((width - text.length) / 2));
    return ' '.repeat(pad) + text;
  };

  let receipt = '';
  receipt += doubleLine + '\n';
  if (company) {
    receipt += center(company.name.toUpperCase()) + '\n';
    if (company.cnpj) receipt += center(`CNPJ: ${company.cnpj}`) + '\n';
    if (company.address) receipt += center(company.address) + '\n';
    if (company.phone) receipt += center(`Tel: ${company.phone}`) + '\n';
  }
  receipt += doubleLine + '\n';
  receipt += center('CUPOM NAO FISCAL') + '\n';
  receipt += line + '\n';

  const dateObj = new Date(sale.date);
  const dateStr = dateObj.toLocaleDateString('pt-BR');
  const timeStr = dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  receipt += `Data: ${dateStr}  Hora: ${timeStr}\n`;
  receipt += `Venda: #${sale.id.slice(-6)}\n`;
  receipt += line + '\n';

  receipt += 'ITEM       QTD   UNIT    TOTAL\n';
  receipt += line + '\n';

  for (const item of sale.items) {
    const name = item.product.name.length > 10
      ? item.product.name.substring(0, 10)
      : item.product.name.padEnd(10);
    const qty = item.quantity.toString().padStart(3);
    const unit = item.product.price.toFixed(2).padStart(7);
    const total = (item.quantity * item.product.price).toFixed(2).padStart(8);
    receipt += `${name} ${qty} ${unit} ${total}\n`;
  }

  receipt += line + '\n';
  receipt += `TOTAL: ${formatCurrency(sale.total).padStart(width - 7)}\n`;
  receipt += `Pagamento: ${sale.paymentMethod}\n`;
  receipt += doubleLine + '\n';
  receipt += center('OBRIGADO PELA PREFERENCIA!') + '\n';
  receipt += doubleLine + '\n';

  return receipt;
}
