const Colors = {
  primary: '#10B981',
  primaryDark: '#059669',
  primaryLight: '#34D399',
  accent: '#F59E0B',
  accentDark: '#D97706',
  danger: '#EF4444',
  dangerDark: '#DC2626',
  success: '#22C55E',
  warning: '#F59E0B',
  info: '#3B82F6',

  bg: '#0A1628',
  bgCard: '#111D32',
  bgCardLight: '#1A2A45',
  bgInput: '#1E3050',
  bgModal: 'rgba(0,0,0,0.7)',

  text: '#F1F5F9',
  textSecondary: '#94A3B8',
  textMuted: '#64748B',
  textDark: '#0F172A',

  border: '#1E3A5F',
  borderLight: '#2A4A6F',
  white: '#FFFFFF',
  black: '#000000',

  light: {
    text: '#F1F5F9',
    background: '#0A1628',
    tint: '#10B981',
    tabIconDefault: '#64748B',
    tabIconSelected: '#10B981',
  },
};

export default Colors;
