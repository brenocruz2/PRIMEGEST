# PDV Smart - Ponto de Venda

## Overview
A robust Point of Sale (PDV) mobile application built with Expo React Native. Designed for touch-screen smart terminals with large buttons and dark theme for comfortable use.

## Architecture
- **Frontend**: Expo React Native with Expo Router (file-based routing)
- **Backend**: Express.js (serves landing page and API)
- **Storage**: AsyncStorage for local data persistence
- **Security**: SHA-256 password hashing via expo-crypto

## Key Features
- Company setup and admin user registration
- Product management (CRUD with categories)
- POS (Point of Sale) with cart and payment methods
- Sales management with cancel/refund (admin password required)
- Cash register control (open/close, supply, withdrawal)
- Receipt generation formatted for 58mm thermal printer

## Project Structure
```
app/
  _layout.tsx          - Root layout with fonts and providers
  index.tsx            - Entry point (redirects to setup or dashboard)
  setup.tsx            - Initial company + admin setup
  dashboard.tsx        - Main menu/dashboard
  products.tsx         - Product list
  product-form.tsx     - Create/edit product
  pdv.tsx              - Point of sale (main selling screen)
  sales.tsx            - Sales history and management
  cash-register.tsx    - Cash register control
  receipt.tsx          - Receipt viewer

lib/
  storage.ts           - AsyncStorage data layer with all business logic
  query-client.ts      - React Query setup

constants/
  colors.ts            - Dark theme color palette
```

## Design
- Dark navy theme with emerald green accents
- Inter font family for clean typography
- Large touch targets for small screen devices
- Professional POS aesthetic

## User Preferences
- Language: Portuguese (Brazil)
- Target: Android smart terminals (maquininhas)
