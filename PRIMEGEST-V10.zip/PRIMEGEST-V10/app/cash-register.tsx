import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Alert,
  Modal,
  TextInput,
  Platform,
  FlatList,
} from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons, Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import {
  getOpenCashRegister,
  openCashRegister,
  closeCashRegister,
  addCashMovement,
  getSales,
  formatCurrency,
  type CashRegister,
  type CashMovement,
  type Sale,
} from '@/lib/storage';

export default function CashRegisterScreen() {
  const insets = useSafeAreaInsets();
  const [register, setRegister] = useState<CashRegister | null>(null);
  const [showOpen, setShowOpen] = useState(false);
  const [showClose, setShowClose] = useState(false);
  const [showMovement, setShowMovement] = useState(false);
  const [movementType, setMovementType] = useState<'supply' | 'withdrawal'>('supply');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [todaySales, setTodaySales] = useState<Sale[]>([]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [])
  );

  async function loadData() {
    const cr = await getOpenCashRegister();
    setRegister(cr);
    const sales = await getSales();
    const today = new Date().toDateString();
    setTodaySales(
      sales.filter(s => new Date(s.date).toDateString() === today && s.status === 'completed')
    );
  }

  async function handleOpen() {
    const amountNum = parseFloat(amount.replace(',', '.'));
    if (isNaN(amountNum) || amountNum < 0) {
      Alert.alert('Erro', 'Informe um valor valido.');
      return;
    }
    await openCashRegister(amountNum);
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowOpen(false);
    setAmount('');
    loadData();
  }

  async function handleClose() {
    const amountNum = parseFloat(amount.replace(',', '.'));
    if (isNaN(amountNum) || amountNum < 0) {
      Alert.alert('Erro', 'Informe o valor de fechamento.');
      return;
    }
    await closeCashRegister(amountNum);
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowClose(false);
    setAmount('');
    loadData();
  }

  async function handleMovement() {
    const amountNum = parseFloat(amount.replace(',', '.'));
    if (isNaN(amountNum) || amountNum <= 0) {
      Alert.alert('Erro', 'Informe um valor valido.');
      return;
    }
    if (!description.trim()) {
      Alert.alert('Erro', 'Informe uma descricao.');
      return;
    }
    await addCashMovement(movementType, amountNum, description.trim());
    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setShowMovement(false);
    setAmount('');
    setDescription('');
    loadData();
  }

  const totalSales = todaySales.reduce((sum, s) => sum + s.total, 0);
  const totalMovements = register?.movements.reduce((sum, m) => sum + m.amount, 0) ?? 0;
  const currentBalance = (register?.openingAmount ?? 0) + totalMovements;

  function getMovementIcon(type: CashMovement['type']) {
    switch (type) {
      case 'sale': return { name: 'arrow-down-circle' as const, color: Colors.success };
      case 'refund': return { name: 'arrow-up-circle' as const, color: Colors.danger };
      case 'supply': return { name: 'arrow-down-circle' as const, color: Colors.info };
      case 'withdrawal': return { name: 'arrow-up-circle' as const, color: Colors.warning };
    }
  }

  function getMovementLabel(type: CashMovement['type']) {
    switch (type) {
      case 'sale': return 'Venda';
      case 'refund': return 'Estorno';
      case 'supply': return 'Suprimento';
      case 'withdrawal': return 'Sangria';
    }
  }

  return (
    <View style={[styles.container, {
      paddingTop: Platform.OS === 'web' ? 67 : insets.top,
    }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </Pressable>
        <Text style={styles.headerTitle}>Controle de Caixa</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, {
          paddingBottom: Platform.OS === 'web' ? 54 : insets.bottom + 20,
        }]}
      >
        {register ? (
          <>
            <View style={styles.balanceCard}>
              <View style={[styles.openBadge, { backgroundColor: Colors.success + '20' }]}>
                <View style={[styles.dotLive, { backgroundColor: Colors.success }]} />
                <Text style={[styles.openBadgeText, { color: Colors.success }]}>Caixa Aberto</Text>
              </View>
              <Text style={styles.balanceLabel}>Saldo Atual</Text>
              <Text style={styles.balanceValue}>{formatCurrency(currentBalance)}</Text>
              <View style={styles.balanceDetails}>
                <View style={styles.balanceDetailItem}>
                  <Text style={styles.detailLabel}>Abertura</Text>
                  <Text style={styles.detailValue}>{formatCurrency(register.openingAmount)}</Text>
                </View>
                <View style={styles.balanceDetailItem}>
                  <Text style={styles.detailLabel}>Vendas</Text>
                  <Text style={[styles.detailValue, { color: Colors.success }]}>{formatCurrency(totalSales)}</Text>
                </View>
                <View style={styles.balanceDetailItem}>
                  <Text style={styles.detailLabel}>Qtd Vendas</Text>
                  <Text style={styles.detailValue}>{todaySales.length}</Text>
                </View>
              </View>
            </View>

            <View style={styles.actionsRow}>
              <Pressable
                style={({ pressed }) => [styles.actionCard, pressed && { opacity: 0.85 }]}
                onPress={() => { setMovementType('supply'); setShowMovement(true); }}
              >
                <Ionicons name="add-circle" size={28} color={Colors.info} />
                <Text style={styles.actionLabel}>Suprimento</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.actionCard, pressed && { opacity: 0.85 }]}
                onPress={() => { setMovementType('withdrawal'); setShowMovement(true); }}
              >
                <Ionicons name="remove-circle" size={28} color={Colors.warning} />
                <Text style={styles.actionLabel}>Sangria</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.actionCard, pressed && { opacity: 0.85 }]}
                onPress={() => setShowClose(true)}
              >
                <Ionicons name="lock-closed" size={28} color={Colors.danger} />
                <Text style={styles.actionLabel}>Fechar</Text>
              </Pressable>
            </View>

            {register.movements.length > 0 && (
              <>
                <Text style={styles.sectionTitle}>Movimentacoes</Text>
                {register.movements.slice().reverse().map((mov) => {
                  const icon = getMovementIcon(mov.type);
                  return (
                    <View key={mov.id} style={styles.movementItem}>
                      <Ionicons name={icon.name} size={24} color={icon.color} />
                      <View style={styles.movementInfo}>
                        <Text style={styles.movementType}>{getMovementLabel(mov.type)}</Text>
                        <Text style={styles.movementDesc}>{mov.description}</Text>
                      </View>
                      <Text style={[styles.movementAmount, {
                        color: mov.amount >= 0 ? Colors.success : Colors.danger,
                      }]}>
                        {mov.amount >= 0 ? '+' : ''}{formatCurrency(Math.abs(mov.amount))}
                      </Text>
                    </View>
                  );
                })}
              </>
            )}
          </>
        ) : (
          <View style={styles.closedState}>
            <View style={styles.closedIconCircle}>
              <Ionicons name="lock-closed" size={40} color={Colors.textMuted} />
            </View>
            <Text style={styles.closedTitle}>Caixa Fechado</Text>
            <Text style={styles.closedText}>Abra o caixa para iniciar as operacoes do dia</Text>
            <Pressable
              style={({ pressed }) => [styles.openBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
              onPress={() => setShowOpen(true)}
            >
              <Ionicons name="lock-open" size={22} color={Colors.white} />
              <Text style={styles.openBtnText}>Abrir Caixa</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>

      <Modal visible={showOpen} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Ionicons name="cash" size={36} color={Colors.primary} />
            <Text style={styles.modalTitle}>Abrir Caixa</Text>
            <Text style={styles.modalSubtext}>Informe o valor inicial do caixa</Text>
            <TextInput
              style={styles.modalInput}
              value={amount}
              onChangeText={setAmount}
              placeholder="0.00"
              placeholderTextColor={Colors.textMuted}
              keyboardType="decimal-pad"
              autoFocus
            />
            <View style={styles.modalBtnRow}>
              <Pressable
                style={({ pressed }) => [styles.cancelBtn, { flex: 1 }, pressed && { opacity: 0.8 }]}
                onPress={() => { setShowOpen(false); setAmount(''); }}
              >
                <Text style={styles.cancelBtnText}>Cancelar</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.confirmBtn, { flex: 1 }, pressed && { opacity: 0.85 }]}
                onPress={handleOpen}
              >
                <Text style={styles.confirmBtnText}>Abrir</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showClose} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Ionicons name="lock-closed" size={36} color={Colors.danger} />
            <Text style={styles.modalTitle}>Fechar Caixa</Text>
            <Text style={styles.modalSubtext}>Informe o valor em caixa para conferencia</Text>
            <View style={styles.closeInfo}>
              <Text style={styles.closeInfoLabel}>Saldo esperado:</Text>
              <Text style={styles.closeInfoValue}>{formatCurrency(currentBalance)}</Text>
            </View>
            <TextInput
              style={styles.modalInput}
              value={amount}
              onChangeText={setAmount}
              placeholder="Valor contado"
              placeholderTextColor={Colors.textMuted}
              keyboardType="decimal-pad"
              autoFocus
            />
            <View style={styles.modalBtnRow}>
              <Pressable
                style={({ pressed }) => [styles.cancelBtn, { flex: 1 }, pressed && { opacity: 0.8 }]}
                onPress={() => { setShowClose(false); setAmount(''); }}
              >
                <Text style={styles.cancelBtnText}>Cancelar</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.dangerConfBtn, { flex: 1 }, pressed && { opacity: 0.85 }]}
                onPress={handleClose}
              >
                <Text style={styles.confirmBtnText}>Fechar Caixa</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showMovement} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Ionicons
              name={movementType === 'supply' ? 'add-circle' : 'remove-circle'}
              size={36}
              color={movementType === 'supply' ? Colors.info : Colors.warning}
            />
            <Text style={styles.modalTitle}>
              {movementType === 'supply' ? 'Suprimento' : 'Sangria'}
            </Text>
            <TextInput
              style={styles.modalInput}
              value={amount}
              onChangeText={setAmount}
              placeholder="Valor (R$)"
              placeholderTextColor={Colors.textMuted}
              keyboardType="decimal-pad"
            />
            <TextInput
              style={styles.modalInput}
              value={description}
              onChangeText={setDescription}
              placeholder="Descricao"
              placeholderTextColor={Colors.textMuted}
            />
            <View style={styles.modalBtnRow}>
              <Pressable
                style={({ pressed }) => [styles.cancelBtn, { flex: 1 }, pressed && { opacity: 0.8 }]}
                onPress={() => { setShowMovement(false); setAmount(''); setDescription(''); }}
              >
                <Text style={styles.cancelBtnText}>Cancelar</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.confirmBtn, { flex: 1 }, pressed && { opacity: 0.85 }]}
                onPress={handleMovement}
              >
                <Text style={styles.confirmBtnText}>Confirmar</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  scrollContent: {
    paddingHorizontal: 20,
    gap: 16,
  },
  balanceCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  openBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 20,
    gap: 6,
    marginBottom: 4,
  },
  dotLive: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  openBadgeText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },
  balanceLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  balanceValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 32,
    color: Colors.text,
  },
  balanceDetails: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  balanceDetailItem: {
    alignItems: 'center',
    gap: 4,
  },
  detailLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textMuted,
  },
  detailValue: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
    color: Colors.text,
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  actionCard: {
    flex: 1,
    backgroundColor: Colors.bgCard,
    borderRadius: 14,
    padding: 16,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  actionLabel: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  sectionTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginTop: 4,
  },
  movementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.bgCard,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  movementInfo: {
    flex: 1,
    gap: 2,
  },
  movementType: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.text,
  },
  movementDesc: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textMuted,
  },
  movementAmount: {
    fontFamily: 'Inter_700Bold',
    fontSize: 15,
  },
  closedState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 60,
    gap: 12,
  },
  closedIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.bgCard,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    borderWidth: 2,
    borderColor: Colors.border,
  },
  closedTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
    color: Colors.text,
  },
  closedText: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  openBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
  },
  openBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.bgModal,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    gap: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  modalTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  modalSubtext: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  modalInput: {
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.border,
    width: '100%',
    textAlign: 'center',
  },
  closeInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    padding: 14,
  },
  closeInfoLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
  },
  closeInfoValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 14,
    color: Colors.primary,
  },
  modalBtnRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  cancelBtn: {
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cancelBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textSecondary,
  },
  confirmBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  dangerConfBtn: {
    backgroundColor: Colors.danger,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  confirmBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
});
