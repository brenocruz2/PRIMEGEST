import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  Alert,
  Platform,
  Modal,
  TextInput,
} from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import {
  getProducts,
  getOpenCashRegister,
  saveSale,
  getAdmin,
  verifyPassword,
  getCompany,
  generateReceipt,
  formatCurrency,
  type Product,
  type CartItem,
} from '@/lib/storage';

const PAYMENT_METHODS = ['Dinheiro', 'Debito', 'Credito', 'PIX'];

export default function PDVScreen() {
  const insets = useSafeAreaInsets();
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const [showCancel, setShowCancel] = useState(false);
  const [cancelPassword, setCancelPassword] = useState('');
  const [showReceipt, setShowReceipt] = useState(false);
  const [receiptText, setReceiptText] = useState('');

  useFocusEffect(
    useCallback(() => {
      loadProducts();
    }, [])
  );

  async function loadProducts() {
    const p = await getProducts();
    setProducts(p.filter(prod => prod.active && prod.stock > 0));
  }

  const categories = Array.from(new Set(products.map(p => p.category)));

  const filteredProducts = selectedCategory
    ? products.filter(p => p.category === selectedCategory)
    : products;

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  function addToCart(product: Product) {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          Alert.alert('Estoque', 'Estoque insuficiente para este produto.');
          return prev;
        }
        return prev.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  }

  function removeFromCart(productId: string) {
    if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setCart(prev => {
      const existing = prev.find(item => item.product.id === productId);
      if (existing && existing.quantity > 1) {
        return prev.map(item =>
          item.product.id === productId
            ? { ...item, quantity: item.quantity - 1 }
            : item
        );
      }
      return prev.filter(item => item.product.id !== productId);
    });
  }

  async function handleFinalizeSale(paymentMethod: string) {
    const register = await getOpenCashRegister();
    if (!register) {
      Alert.alert('Caixa Fechado', 'Abra o caixa antes de realizar vendas.');
      setShowPayment(false);
      return;
    }

    try {
      const sale = await saveSale({
        items: cart,
        total: cartTotal,
        paymentMethod,
        date: new Date().toISOString(),
        status: 'completed',
      });

      const company = await getCompany();
      const receipt = generateReceipt(sale, company);
      setReceiptText(receipt);

      if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setCart([]);
      setShowPayment(false);
      setShowReceipt(true);
      loadProducts();
    } catch (e) {
      Alert.alert('Erro', 'Falha ao finalizar venda.');
    }
  }

  async function handleCancelSale() {
    const admin = await getAdmin();
    if (!admin) return;

    const valid = await verifyPassword(cancelPassword, admin.passwordHash);
    if (!valid) {
      Alert.alert('Erro', 'Senha incorreta.');
      return;
    }

    if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
    setCart([]);
    setShowCancel(false);
    setCancelPassword('');
  }

  function renderProductItem({ item }: { item: Product }) {
    const inCart = cart.find(c => c.product.id === item.id);
    return (
      <Pressable
        onPress={() => addToCart(item)}
        style={({ pressed }) => [
          styles.productTile,
          pressed && { opacity: 0.85, transform: [{ scale: 0.96 }] },
          inCart && styles.productTileInCart,
        ]}
      >
        <View style={styles.tileTop}>
          <Text style={styles.tileName} numberOfLines={2}>{item.name}</Text>
          {inCart && (
            <View style={styles.tileQtyBadge}>
              <Text style={styles.tileQtyText}>{inCart.quantity}</Text>
            </View>
          )}
        </View>
        <Text style={styles.tilePrice}>{formatCurrency(item.price)}</Text>
        <Text style={styles.tileStock}>{item.stock} em estoque</Text>
      </Pressable>
    );
  }

  function renderCartItem({ item }: { item: CartItem }) {
    return (
      <View style={styles.cartItem}>
        <View style={styles.cartItemInfo}>
          <Text style={styles.cartItemName} numberOfLines={1}>{item.product.name}</Text>
          <Text style={styles.cartItemUnit}>{formatCurrency(item.product.price)} un.</Text>
        </View>
        <View style={styles.cartItemControls}>
          <Pressable
            onPress={() => removeFromCart(item.product.id)}
            style={({ pressed }) => [styles.qtyBtn, pressed && { opacity: 0.6 }]}
          >
            <Ionicons name="remove" size={18} color={Colors.text} />
          </Pressable>
          <Text style={styles.qtyText}>{item.quantity}</Text>
          <Pressable
            onPress={() => addToCart(item.product)}
            style={({ pressed }) => [styles.qtyBtn, pressed && { opacity: 0.6 }]}
          >
            <Ionicons name="add" size={18} color={Colors.text} />
          </Pressable>
        </View>
        <Text style={styles.cartItemTotal}>
          {formatCurrency(item.product.price * item.quantity)}
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, {
      paddingTop: Platform.OS === 'web' ? 67 : insets.top,
    }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </Pressable>
        <Text style={styles.headerTitle}>Frente de Caixa</Text>
        <View style={styles.cartBadgeWrap}>
          <Ionicons name="cart" size={24} color={Colors.text} />
          {cartCount > 0 && (
            <View style={styles.cartCountBadge}>
              <Text style={styles.cartCountText}>{cartCount}</Text>
            </View>
          )}
        </View>
      </View>

      <ScrollableCategories
        categories={categories}
        selected={selectedCategory}
        onSelect={setSelectedCategory}
      />

      <FlatList
        data={filteredProducts}
        keyExtractor={item => item.id}
        renderItem={renderProductItem}
        numColumns={2}
        columnWrapperStyle={styles.productRow}
        contentContainerStyle={styles.productGrid}
        scrollEnabled={filteredProducts.length > 0}
        ListEmptyComponent={
          <View style={styles.emptyProducts}>
            <Ionicons name="cube-outline" size={40} color={Colors.textMuted} />
            <Text style={styles.emptyText}>Nenhum produto disponivel</Text>
          </View>
        }
        style={{ flex: 1 }}
      />

      {cart.length > 0 && (
        <View style={[styles.cartPanel, {
          paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 8,
        }]}>
          <View style={styles.cartHeader}>
            <Text style={styles.cartTitle}>Carrinho ({cartCount} itens)</Text>
            <Pressable
              onPress={() => {
                if (cart.length > 0) setShowCancel(true);
              }}
              style={({ pressed }) => [pressed && { opacity: 0.6 }]}
            >
              <Ionicons name="trash-outline" size={20} color={Colors.danger} />
            </Pressable>
          </View>
          <FlatList
            data={cart}
            keyExtractor={item => item.product.id}
            renderItem={renderCartItem}
            style={styles.cartList}
            scrollEnabled={cart.length > 3}
          />
          <View style={styles.cartFooter}>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>TOTAL</Text>
              <Text style={styles.totalValue}>{formatCurrency(cartTotal)}</Text>
            </View>
            <Pressable
              style={({ pressed }) => [styles.payBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
              onPress={() => setShowPayment(true)}
            >
              <MaterialCommunityIcons name="cash-register" size={22} color={Colors.white} />
              <Text style={styles.payBtnText}>Finalizar Venda</Text>
            </Pressable>
          </View>
        </View>
      )}

      <Modal visible={showPayment} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Forma de Pagamento</Text>
            <Text style={styles.modalTotal}>{formatCurrency(cartTotal)}</Text>
            <View style={styles.paymentGrid}>
              {PAYMENT_METHODS.map(method => (
                <Pressable
                  key={method}
                  style={({ pressed }) => [styles.paymentBtn, pressed && { opacity: 0.85 }]}
                  onPress={() => handleFinalizeSale(method)}
                >
                  <Ionicons
                    name={
                      method === 'Dinheiro' ? 'cash-outline' :
                      method === 'PIX' ? 'qr-code-outline' :
                      'card-outline'
                    }
                    size={28}
                    color={Colors.primary}
                  />
                  <Text style={styles.paymentBtnText}>{method}</Text>
                </Pressable>
              ))}
            </View>
            <Pressable
              style={({ pressed }) => [styles.cancelModalBtn, pressed && { opacity: 0.8 }]}
              onPress={() => setShowPayment(false)}
            >
              <Text style={styles.cancelModalBtnText}>Voltar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showCancel} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Ionicons name="warning" size={40} color={Colors.danger} />
            <Text style={styles.modalTitle}>Cancelar Venda</Text>
            <Text style={styles.modalSubtext}>Informe a senha do administrador</Text>
            <TextInput
              style={styles.modalInput}
              value={cancelPassword}
              onChangeText={setCancelPassword}
              placeholder="Senha"
              placeholderTextColor={Colors.textMuted}
              secureTextEntry
              autoFocus
            />
            <View style={styles.modalBtnRow}>
              <Pressable
                style={({ pressed }) => [styles.cancelModalBtn, { flex: 1 }, pressed && { opacity: 0.8 }]}
                onPress={() => { setShowCancel(false); setCancelPassword(''); }}
              >
                <Text style={styles.cancelModalBtnText}>Voltar</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.dangerBtn, { flex: 1 }, pressed && { opacity: 0.85 }]}
                onPress={handleCancelSale}
              >
                <Text style={styles.dangerBtnText}>Cancelar Venda</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showReceipt} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { maxHeight: '80%' }]}>
            <Text style={styles.modalTitle}>Comanda</Text>
            <FlatList
              data={[receiptText]}
              keyExtractor={(_, i) => i.toString()}
              renderItem={({ item }) => (
                <View style={styles.receiptBox}>
                  <Text style={styles.receiptText}>{item}</Text>
                </View>
              )}
              style={{ maxHeight: 400 }}
            />
            <Pressable
              style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
              onPress={() => setShowReceipt(false)}
            >
              <Ionicons name="checkmark" size={20} color={Colors.white} />
              <Text style={styles.primaryBtnText}>Fechar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function ScrollableCategories({
  categories,
  selected,
  onSelect,
}: {
  categories: string[];
  selected: string | null;
  onSelect: (cat: string | null) => void;
}) {
  return (
    <FlatList
      data={['Todos', ...categories]}
      keyExtractor={item => item}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.categoryList}
      scrollEnabled={categories.length > 3}
      renderItem={({ item }) => {
        const isSelected = item === 'Todos' ? selected === null : selected === item;
        return (
          <Pressable
            onPress={() => {
              onSelect(item === 'Todos' ? null : item);
              if (Platform.OS !== 'web') Haptics.selectionAsync();
            }}
            style={[styles.categoryChip, isSelected && styles.categoryChipActive]}
          >
            <Text style={[styles.categoryChipText, isSelected && styles.categoryChipTextActive]}>
              {item}
            </Text>
          </Pressable>
        );
      }}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  headerTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  cartBadgeWrap: {
    position: 'relative',
  },
  cartCountBadge: {
    position: 'absolute',
    top: -6,
    right: -8,
    backgroundColor: Colors.danger,
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartCountText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 11,
    color: Colors.white,
  },
  categoryList: {
    paddingHorizontal: 20,
    gap: 8,
    paddingVertical: 8,
  },
  categoryChip: {
    backgroundColor: Colors.bgInput,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  categoryChipActive: {
    backgroundColor: Colors.primary + '20',
    borderColor: Colors.primary,
  },
  categoryChipText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  categoryChipTextActive: {
    color: Colors.primary,
  },
  productGrid: {
    paddingHorizontal: 20,
    paddingBottom: 8,
    gap: 10,
  },
  productRow: {
    gap: 10,
  },
  productTile: {
    flex: 1,
    backgroundColor: Colors.bgCard,
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: 6,
  },
  productTileInCart: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary + '10',
  },
  tileTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  tileName: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.text,
    flex: 1,
  },
  tileQtyBadge: {
    backgroundColor: Colors.primary,
    borderRadius: 10,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 4,
  },
  tileQtyText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
    color: Colors.white,
  },
  tilePrice: {
    fontFamily: 'Inter_700Bold',
    fontSize: 16,
    color: Colors.primary,
  },
  tileStock: {
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
    color: Colors.textMuted,
  },
  emptyProducts: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 60,
    gap: 8,
  },
  emptyText: {
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
    color: Colors.textMuted,
  },
  cartPanel: {
    backgroundColor: Colors.bgCard,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderTopWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 20,
    paddingTop: 16,
    maxHeight: '45%',
  },
  cartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cartTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  cartList: {
    maxHeight: 120,
  },
  cartItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  cartItemInfo: {
    flex: 1,
    gap: 2,
  },
  cartItemName: {
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
    color: Colors.text,
  },
  cartItemUnit: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textMuted,
  },
  cartItemControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 12,
  },
  qtyBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: Colors.bgInput,
    justifyContent: 'center',
    alignItems: 'center',
  },
  qtyText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.text,
    minWidth: 20,
    textAlign: 'center',
  },
  cartItemTotal: {
    fontFamily: 'Inter_700Bold',
    fontSize: 14,
    color: Colors.primary,
    minWidth: 70,
    textAlign: 'right',
  },
  cartFooter: {
    gap: 12,
    paddingTop: 12,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textSecondary,
    letterSpacing: 1,
  },
  totalValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 24,
    color: Colors.text,
  },
  payBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  payBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.bgModal,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    gap: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  modalTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  modalSubtext: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  modalTotal: {
    fontFamily: 'Inter_700Bold',
    fontSize: 28,
    color: Colors.primary,
  },
  modalInput: {
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.border,
    width: '100%',
    textAlign: 'center',
  },
  paymentGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    width: '100%',
  },
  paymentBtn: {
    flex: 1,
    minWidth: '40%',
    backgroundColor: Colors.bgInput,
    borderRadius: 14,
    paddingVertical: 20,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  paymentBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.text,
  },
  modalBtnRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  cancelModalBtn: {
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cancelModalBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textSecondary,
  },
  dangerBtn: {
    backgroundColor: Colors.danger,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  dangerBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  primaryBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 14,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    width: '100%',
  },
  primaryBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  receiptBox: {
    backgroundColor: Colors.white,
    borderRadius: 8,
    padding: 12,
  },
  receiptText: {
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
    fontSize: 11,
    color: Colors.black,
    lineHeight: 16,
  },
});
