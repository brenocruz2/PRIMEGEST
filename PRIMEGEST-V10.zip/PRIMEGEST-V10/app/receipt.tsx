import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Platform,
  Alert,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Colors from '@/constants/colors';

export default function ReceiptScreen() {
  const insets = useSafeAreaInsets();
  const { text } = useLocalSearchParams<{ text: string }>();

  function handlePrint() {
    Alert.alert(
      'Impressao',
      'A funcao de impressao esta preparada para enviar comandos ESC/POS via Intent do Android. Conecte uma impressora termica 58mm para utilizar.',
    );
  }

  return (
    <View style={[styles.container, {
      paddingTop: Platform.OS === 'web' ? 67 : insets.top,
      paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom,
    }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </Pressable>
        <Text style={styles.headerTitle}>Comanda</Text>
        <Pressable onPress={handlePrint} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <Ionicons name="print" size={24} color={Colors.primary} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.receiptBox}>
          <Text style={styles.receiptText}>{text || 'Sem dados'}</Text>
        </View>
      </ScrollView>

      <Pressable
        style={({ pressed }) => [styles.printBtn, pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] }]}
        onPress={handlePrint}
      >
        <Ionicons name="print" size={22} color={Colors.white} />
        <Text style={styles.printBtnText}>Imprimir Comanda</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    flex: 1,
  },
  receiptBox: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
  },
  receiptText: {
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
    fontSize: 12,
    color: Colors.black,
    lineHeight: 18,
  },
  printBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 20,
    marginBottom: 8,
  },
  printBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.white,
  },
});
