import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Platform,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { useFocusEffect } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { getCompany, getOpenCashRegister, getSales, formatCurrency, type Company, type CashRegister } from '@/lib/storage';

interface MenuItemProps {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  color: string;
  onPress: () => void;
  badge?: string;
}

function MenuItem({ icon, title, subtitle, color, onPress, badge }: MenuItemProps) {
  return (
    <Pressable
      style={({ pressed }) => [styles.menuItem, pressed && styles.menuItemPressed]}
      onPress={() => {
        if (Platform.OS !== 'web') Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        onPress();
      }}
    >
      <View style={[styles.menuIconBox, { backgroundColor: color + '20' }]}>
        {icon}
      </View>
      <View style={styles.menuTextBox}>
        <Text style={styles.menuTitle}>{title}</Text>
        <Text style={styles.menuSubtitle}>{subtitle}</Text>
      </View>
      {badge && (
        <View style={[styles.badge, { backgroundColor: color }]}>
          <Text style={styles.badgeText}>{badge}</Text>
        </View>
      )}
      <Ionicons name="chevron-forward" size={20} color={Colors.textMuted} />
    </Pressable>
  );
}

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const [company, setCompany] = useState<Company | null>(null);
  const [cashRegister, setCashRegister] = useState<CashRegister | null>(null);
  const [todaySales, setTodaySales] = useState(0);
  const [todayTotal, setTodayTotal] = useState(0);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [])
  );

  async function loadData() {
    const c = await getCompany();
    setCompany(c);
    const cr = await getOpenCashRegister();
    setCashRegister(cr);
    const sales = await getSales();
    const today = new Date().toDateString();
    const todaysSales = sales.filter(
      s => new Date(s.date).toDateString() === today && s.status === 'completed'
    );
    setTodaySales(todaysSales.length);
    setTodayTotal(todaysSales.reduce((sum, s) => sum + s.total, 0));
  }

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={[styles.content, {
        paddingTop: Platform.OS === 'web' ? 67 : insets.top + 16,
        paddingBottom: Platform.OS === 'web' ? 54 : insets.bottom + 20,
      }]}
    >
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.greeting}>PDV Smart</Text>
          <Text style={styles.companyName}>{company?.name || 'Minha Empresa'}</Text>
        </View>
        <View style={[styles.statusBadge, {
          backgroundColor: cashRegister ? Colors.success + '20' : Colors.danger + '20',
        }]}>
          <View style={[styles.statusDot, {
            backgroundColor: cashRegister ? Colors.success : Colors.danger,
          }]} />
          <Text style={[styles.statusText, {
            color: cashRegister ? Colors.success : Colors.danger,
          }]}>
            {cashRegister ? 'Caixa Aberto' : 'Caixa Fechado'}
          </Text>
        </View>
      </View>

      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Ionicons name="receipt-outline" size={20} color={Colors.primary} />
          <Text style={styles.statValue}>{todaySales}</Text>
          <Text style={styles.statLabel}>Vendas Hoje</Text>
        </View>
        <View style={styles.statCard}>
          <Ionicons name="cash-outline" size={20} color={Colors.accent} />
          <Text style={styles.statValue}>{formatCurrency(todayTotal)}</Text>
          <Text style={styles.statLabel}>Faturamento</Text>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Menu Principal</Text>

      <View style={styles.menuGrid}>
        <MenuItem
          icon={<MaterialCommunityIcons name="point-of-sale" size={28} color={Colors.primary} />}
          title="PDV"
          subtitle="Frente de caixa"
          color={Colors.primary}
          onPress={() => router.push('/pdv')}
        />
        <MenuItem
          icon={<Ionicons name="cube-outline" size={28} color={Colors.info} />}
          title="Produtos"
          subtitle="Cadastro e estoque"
          color={Colors.info}
          onPress={() => router.push('/products')}
        />
        <MenuItem
          icon={<Ionicons name="receipt-outline" size={28} color={Colors.accent} />}
          title="Vendas"
          subtitle="Historico e estornos"
          color={Colors.accent}
          onPress={() => router.push('/sales')}
          badge={todaySales > 0 ? todaySales.toString() : undefined}
        />
        <MenuItem
          icon={<Feather name="dollar-sign" size={28} color={Colors.success} />}
          title="Caixa"
          subtitle="Controle de caixa"
          color={Colors.success}
          onPress={() => router.push('/cash-register')}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  content: {
    paddingHorizontal: 20,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  greeting: {
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
    color: Colors.primary,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  companyName: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
    color: Colors.text,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 28,
  },
  statCard: {
    flex: 1,
    backgroundColor: Colors.bgCard,
    borderRadius: 16,
    padding: 16,
    alignItems: 'flex-start',
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  statValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  statLabel: {
    fontFamily: 'Inter_400Regular',
    fontSize: 12,
    color: Colors.textSecondary,
  },
  sectionTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 12,
  },
  menuGrid: {
    gap: 10,
  },
  menuItem: {
    backgroundColor: Colors.bgCard,
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  menuItemPressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
  menuIconBox: {
    width: 52,
    height: 52,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuTextBox: {
    flex: 1,
    gap: 2,
  },
  menuTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.text,
  },
  menuSubtitle: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  badge: {
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 3,
    minWidth: 24,
    alignItems: 'center',
  },
  badgeText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
    color: Colors.white,
  },
});
