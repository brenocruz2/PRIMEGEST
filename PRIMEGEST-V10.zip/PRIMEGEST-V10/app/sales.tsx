import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  Alert,
  Modal,
  TextInput,
  Platform,
} from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import {
  getSales,
  cancelSale,
  refundSale,
  getAdmin,
  verifyPassword,
  getCompany,
  generateReceipt,
  formatCurrency,
  type Sale,
} from '@/lib/storage';

export default function SalesScreen() {
  const insets = useSafeAreaInsets();
  const [sales, setSales] = useState<Sale[]>([]);
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [showActions, setShowActions] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [passwordAction, setPasswordAction] = useState<'cancel' | 'refund'>('cancel');
  const [password, setPassword] = useState('');
  const [showReceipt, setShowReceipt] = useState(false);
  const [receiptText, setReceiptText] = useState('');

  useFocusEffect(
    useCallback(() => {
      loadSales();
    }, [])
  );

  async function loadSales() {
    const s = await getSales();
    setSales(s.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  }

  function getStatusColor(status: Sale['status']) {
    switch (status) {
      case 'completed': return Colors.success;
      case 'cancelled': return Colors.danger;
      case 'refunded': return Colors.warning;
    }
  }

  function getStatusLabel(status: Sale['status']) {
    switch (status) {
      case 'completed': return 'Concluida';
      case 'cancelled': return 'Cancelada';
      case 'refunded': return 'Estornada';
    }
  }

  function handleSalePress(sale: Sale) {
    setSelectedSale(sale);
    setShowActions(true);
  }

  function requestPassword(action: 'cancel' | 'refund') {
    setPasswordAction(action);
    setShowActions(false);
    setShowPassword(true);
  }

  async function handlePasswordConfirm() {
    const admin = await getAdmin();
    if (!admin) return;

    const valid = await verifyPassword(password, admin.passwordHash);
    if (!valid) {
      Alert.alert('Erro', 'Senha incorreta.');
      return;
    }

    if (selectedSale) {
      if (passwordAction === 'cancel') {
        await cancelSale(selectedSale.id);
      } else {
        await refundSale(selectedSale.id);
      }
      if (Platform.OS !== 'web') Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setShowPassword(false);
      setPassword('');
      loadSales();
    }
  }

  async function handleViewReceipt() {
    if (selectedSale) {
      const company = await getCompany();
      const receipt = generateReceipt(selectedSale, company);
      setReceiptText(receipt);
      setShowActions(false);
      setShowReceipt(true);
    }
  }

  function renderSale({ item }: { item: Sale }) {
    const date = new Date(item.date);
    const statusColor = getStatusColor(item.status);

    return (
      <Pressable
        onPress={() => handleSalePress(item)}
        style={({ pressed }) => [styles.saleCard, pressed && { opacity: 0.85 }]}
      >
        <View style={styles.saleHeader}>
          <Text style={styles.saleId}>#{item.id.slice(-6)}</Text>
          <View style={[styles.statusBadge, { backgroundColor: statusColor + '20' }]}>
            <Text style={[styles.statusText, { color: statusColor }]}>
              {getStatusLabel(item.status)}
            </Text>
          </View>
        </View>
        <View style={styles.saleMeta}>
          <Text style={styles.saleDate}>
            {date.toLocaleDateString('pt-BR')} {date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
          </Text>
          <Text style={styles.saleMethod}>{item.paymentMethod}</Text>
        </View>
        <View style={styles.saleFooter}>
          <Text style={styles.saleItems}>{item.items.length} itens</Text>
          <Text style={styles.saleTotal}>{formatCurrency(item.total)}</Text>
        </View>
      </Pressable>
    );
  }

  return (
    <View style={[styles.container, {
      paddingTop: Platform.OS === 'web' ? 67 : insets.top,
    }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={({ pressed }) => [pressed && { opacity: 0.6 }]}>
          <Ionicons name="arrow-back" size={24} color={Colors.text} />
        </Pressable>
        <Text style={styles.headerTitle}>Vendas</Text>
        <View style={{ width: 24 }} />
      </View>

      <FlatList
        data={sales}
        keyExtractor={item => item.id}
        renderItem={renderSale}
        contentContainerStyle={[styles.list, {
          paddingBottom: Platform.OS === 'web' ? 54 : insets.bottom + 20,
        }]}
        scrollEnabled={sales.length > 0}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="receipt-outline" size={48} color={Colors.textMuted} />
            <Text style={styles.emptyTitle}>Nenhuma venda registrada</Text>
          </View>
        }
      />

      <Modal visible={showActions} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Venda #{selectedSale?.id.slice(-6)}</Text>
            <Text style={styles.modalTotal}>{selectedSale && formatCurrency(selectedSale.total)}</Text>

            <Pressable
              style={({ pressed }) => [styles.actionItem, pressed && { opacity: 0.85 }]}
              onPress={handleViewReceipt}
            >
              <Ionicons name="receipt-outline" size={22} color={Colors.info} />
              <Text style={styles.actionItemText}>Ver Comanda</Text>
            </Pressable>

            {selectedSale?.status === 'completed' && (
              <>
                <Pressable
                  style={({ pressed }) => [styles.actionItem, pressed && { opacity: 0.85 }]}
                  onPress={() => requestPassword('cancel')}
                >
                  <Ionicons name="close-circle-outline" size={22} color={Colors.danger} />
                  <Text style={[styles.actionItemText, { color: Colors.danger }]}>Cancelar Venda</Text>
                </Pressable>
                <Pressable
                  style={({ pressed }) => [styles.actionItem, pressed && { opacity: 0.85 }]}
                  onPress={() => requestPassword('refund')}
                >
                  <Ionicons name="refresh-circle-outline" size={22} color={Colors.warning} />
                  <Text style={[styles.actionItemText, { color: Colors.warning }]}>Estornar Venda</Text>
                </Pressable>
              </>
            )}

            <Pressable
              style={({ pressed }) => [styles.closeBtn, pressed && { opacity: 0.8 }]}
              onPress={() => setShowActions(false)}
            >
              <Text style={styles.closeBtnText}>Fechar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      <Modal visible={showPassword} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Ionicons name="lock-closed" size={36} color={Colors.accent} />
            <Text style={styles.modalTitle}>Senha do Administrador</Text>
            <Text style={styles.modalSubtext}>
              {passwordAction === 'cancel' ? 'Confirme para cancelar a venda' : 'Confirme para estornar a venda'}
            </Text>
            <TextInput
              style={styles.modalInput}
              value={password}
              onChangeText={setPassword}
              placeholder="Senha"
              placeholderTextColor={Colors.textMuted}
              secureTextEntry
              autoFocus
            />
            <View style={styles.modalBtnRow}>
              <Pressable
                style={({ pressed }) => [styles.closeBtn, { flex: 1 }, pressed && { opacity: 0.8 }]}
                onPress={() => { setShowPassword(false); setPassword(''); }}
              >
                <Text style={styles.closeBtnText}>Voltar</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [
                  passwordAction === 'cancel' ? styles.dangerConfirmBtn : styles.warningConfirmBtn,
                  { flex: 1 },
                  pressed && { opacity: 0.85 },
                ]}
                onPress={handlePasswordConfirm}
              >
                <Text style={styles.confirmBtnText}>Confirmar</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={showReceipt} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { maxHeight: '80%' }]}>
            <Text style={styles.modalTitle}>Comanda</Text>
            <View style={styles.receiptBox}>
              <Text style={styles.receiptText}>{receiptText}</Text>
            </View>
            <Pressable
              style={({ pressed }) => [styles.primaryBtn, pressed && { opacity: 0.85 }]}
              onPress={() => setShowReceipt(false)}
            >
              <Text style={styles.primaryBtnText}>Fechar</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  list: {
    paddingHorizontal: 20,
    gap: 10,
  },
  saleCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: 10,
  },
  saleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  saleId: {
    fontFamily: 'Inter_700Bold',
    fontSize: 16,
    color: Colors.text,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
  },
  saleMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  saleDate: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  saleMethod: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
    color: Colors.textSecondary,
  },
  saleFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  saleItems: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    color: Colors.textMuted,
  },
  saleTotal: {
    fontFamily: 'Inter_700Bold',
    fontSize: 18,
    color: Colors.primary,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 80,
    gap: 8,
  },
  emptyTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 16,
    color: Colors.textSecondary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.bgModal,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: Colors.bgCard,
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    gap: 16,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  modalTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 20,
    color: Colors.text,
  },
  modalTotal: {
    fontFamily: 'Inter_700Bold',
    fontSize: 24,
    color: Colors.primary,
  },
  modalSubtext: {
    fontFamily: 'Inter_400Regular',
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  modalInput: {
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontFamily: 'Inter_400Regular',
    fontSize: 16,
    color: Colors.text,
    borderWidth: 1,
    borderColor: Colors.border,
    width: '100%',
    textAlign: 'center',
  },
  actionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    width: '100%',
    paddingVertical: 14,
    paddingHorizontal: 16,
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  actionItemText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
    color: Colors.text,
  },
  modalBtnRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  closeBtn: {
    backgroundColor: Colors.bgInput,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    width: '100%',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  closeBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.textSecondary,
  },
  dangerConfirmBtn: {
    backgroundColor: Colors.danger,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  warningConfirmBtn: {
    backgroundColor: Colors.warning,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  confirmBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  primaryBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    width: '100%',
  },
  primaryBtnText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
    color: Colors.white,
  },
  receiptBox: {
    backgroundColor: Colors.white,
    borderRadius: 8,
    padding: 12,
    width: '100%',
  },
  receiptText: {
    fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }),
    fontSize: 11,
    color: Colors.black,
    lineHeight: 16,
  },
});
